local localization = {
	["medkit"] = {
		en="Kit Medico",
		lv="Med Kit",
		ru="",
	},
	["first_aid"] = {
		en="Primeros auxilios",
		lv="First Aid",
		ru="",
	},
	["bandage"] = {
		en="Bendaje",
		lv="Bandage",
		ru="",
	},
	["energy_drink"] = {
		en="Bebida energética",
		lv="Energy Drink",
		ru="",
	},
	["painkiller"] = {
		en="Analgésico",
		lv="Painkiller",
		ru="",
	},
	["helmet1"] = {
		en="Casco (Lv.1)",
		lv="Helmet (Lv.1)",
		ru="",
	},
	["helmet2"] = {
		en="Casco (Lv.2)",
		lv="Helmet (Lv.2)",
		ru="",
	},
	["helmet3"] = {
		en="Casco (Lv.3)",
		lv="Helmet (Lv.3)",
		ru="",
	},
	["backpack_small"] = {
		en="Mochila (Lv.1)",
		lv="Backpack (Lv.1)",
		ru="",
	},
	["backpack_medium"] = {
		en="Mochila (Lv.2)",
		lv="Backpack (Lv.2)",
		ru="",
	},
	["backpack_large"] = {
		en="Mochila (Lv.3)",
		lv="Backpack (Lv.3)",
		ru="",
	},
	["armor1"] = {
		en="Armadura (Lv.1)",
		lv="Armor (Lv.1)",
		ru="",
	},
	["armor2"] = {
		en="Armadura (Lv.2)",
		lv="Armor (Lv.2)",
		ru="",
	},
	["armor3"] = {
		en="Armadura (Lv.3)",
		lv="Armor (Lv.3)",
		ru="",
	},
	["jerrycan"] = {
		en="Combustible",
		lv="Jerry Can",
		ru="",
	},
	["ammo_9mm"] = {
		en="9mm",
		lv="9mm",
		ru="",
	},
	["ammo_762mm"] = {
		en="7.62mm",
		lv="7.62mm",
		ru="",
	},
	["ammo_12gauge"] = {
		en="12 Calibre",
		lv="12 Gauge",
		ru="",
	},
	["ammo_556mm"] = {
		en="5.56mm",
		lv="5.56mm",
		ru="",
	},
	["molotov"] = {
		en="Molotov",
		lv="Molotov",
		ru="",
	},
	["grenade"] = {
		en="Frag Grenada",
		lv="Frag Grenade",
		ru="",
	},
	["awm"] = {
		en="AWM",
		lv="AWM",
		ru="",
	},
	["ak47"] = {
		en="AK47",
		lv="AK47",
		ru="",
	},
	["m16a4"] = {
		en="M16A4",
		lv="M16A4",
		ru="",
	},
	["kar98k"] = {
		en="Kar98K",
		lv="Kar98K",
		ru="",
	},
	["shotgun"] = {
		en="Escopeta",
		lv="Shotgun",
		ru="",
	},
	["mp5"] = {
		en="MP5",
		lv="MP5",
		ru="",
	},
	["uzi"] = {
		en="UZI",
		lv="UZI",
		ru="",
	},
	["crowbar"] = {
		en="Palanca",
		lv="Crowbar",
		ru="",
	},
	["machete"] = {
		en="Machete",
		lv="Machete",
		ru="",
	},
	["colt45"] = {
		en="Colt 45",
		lv="Colt 45",
		ru="",
	},
	["pan"] = {
		en="Pan",
		lv="Pan",
		ru="",
	},
	["play"] = {
		en="JOGAR",
		lv="PLAY",
		ru="",
	},
	["lobby1"] = {
		en="%s JOGADORES DE %s",
		lv="PLAYERS %s OUT OF %s",
		ru="",
	},
	["lobby2"] = {
		en="COMEÇA EM %s SEGUNDOS!",
		lv="STARTING IN %s SECONDS",
		ru="",
	},
	["dead1"] = {
		en="TENTE NA PRÓXIMA VEZ!",
		lv="BETTER LUCK NEXT TIME!",
		ru="",
	},
	["dead2"] = {
		en="PARABÉNS GANHADOR !",
		lv="WINNER WINNER CHICKEN DINNER!",
		ru="",
	},
	["rank"] = {
		en="RANK",
		lv="RANK",
		ru="",
	},
	["kill"] = {
		en="MATOU",
		lv="KILL",
		ru="",
	},
	["players"] = {
		en="players",
		lv="players",
		ru="",
	},
	["exitdead"] = {
		en="VOLTAR PARA LOBBY",
		lv="Exit To Lobby",
		ru="",
	},
	["exitplane"] = {
		en="SAIR DO AVIAO",
		lv="EXIT Plane",
		ru="",
	},
	["parachute"] = {
		en="ABRIR PARAQUEDAS",
		lv="RELEASE Parachute",
		ru="",
	},
	["kill1"] = {
		en="%s Matou %s by headshot with %s - #FFFFFF%s left",
		lv="%s killed %s by headshot with %s - #FFFFFF%s left",
		ru="",
	},
	["kill2"] = {
		en="%s Matou %s with %s - #FFFFFF%s left",
		lv="%s killed %s with %s - #FFFFFF%s left",
		ru="",
	},
	["kill3"] = {
		en="%s Morreu - #FFFFFF%s left",
		lv="%s died - #FFFFFF%s left",
		ru="",
	},
	["kills"] = {
		en="%s Kills",
		lv="%s Kills",
		ru="",
	},
	["killed"] = {
		en="KILLS",
		lv="KILLED",
		ru="",
	},
	["alive"] = {
		en="VIVOS",
		lv="ALIVE",
		ru="",
	},
	["ground"] = {
		en="LOOT",
		lv="Ground",
		ru="",
	},
	["inventory"] = {
		en="Inventario",
		lv="Inventory",
		ru="",
	},
	["weight"] = {
		en="Peso",
		lv="Weight",
		ru="",
	},
	["split1"] = {
		en="Input amount of #FFFFFF%s",
		lv="Input amount of #FFFFFF%s",
		ru="",
	},
	["split2"] = {
		en="TOMAR",
		lv="TAKE",
		ru="", -- šitos divus vārdus neraksti lielāk kā lv iztūlkotais
	},
	["split3"] = {
		en="Cancelar",
		lv="Cancel",
		ru="", -- šitos divus vārdus neraksti lielāk kā lv iztūlkotais
	},
	["tocancel"] = {
		en="CANCELAR",
		lv="LAI ATCELTU",
		ru="",
	},
	["you"] = {
		en="TU",
		lv="YOU",
		ru="",
	},
};

function getPlayerLanguage(player)
	if (not player) then player = localPlayer; end
	local lang = getElementData(player,"lang") or "en";
	if (lang) then
		return lang;
	end
	return false;
end

function translateLocalization(text,player,...)
	if (not player) then player = localPlayer; end
	local lang = getPlayerLanguage(player);
	if (lang and localization[text]) then
		local trans = localization[text][lang];
		if (...) then
			trans = trans:format(...);
		end
		return trans;
	end
	return false;
end